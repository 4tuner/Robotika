movie = input("What's your favorite movie? ")

if movie == "Avengers Endgame" or movie == "Titanic":
    print("Good choice!")
elif movie == "Star Wars":
    print("Also a good choice!")
else:
    print("You really are an interesting specimen")