from robot_control_class import RobotControl

rc = RobotControl()

b = rc.get_laser_full()

print ("Position 0: ", b[0])
print ("Position 360: ", b[360])
print ("Position 719: ", b[719])