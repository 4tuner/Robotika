from robot_control_class import RobotControl

rc = RobotControl()

user_input = int(input("Please enter a number between 0 and 719: "))

laser_reading = rc.get_laser(user_input)

print('The Laser value received is: ',laser_reading)