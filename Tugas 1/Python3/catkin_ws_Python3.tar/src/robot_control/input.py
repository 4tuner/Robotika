name = input("What's your name? ")

print("Nice to meet you, " + name)