age = int(input("What's your age? "))

age2 = age + 1

print("So next year you will be %d years old!" % age2)